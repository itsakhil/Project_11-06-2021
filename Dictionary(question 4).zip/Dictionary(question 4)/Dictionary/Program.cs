﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Checkpath
{
    public string livepath { get; private set; }

    public Checkpath(string path)
    {
        livepath = path;
    }

    public void changedir(string newPath)
    {
        if (newPath == "/")
        {
            livepath = "/";
            return;
        }

        while (newPath.Length > 0)
        {
            if (newPath.Length > 1)
            {
                if (newPath.Substring(0, 2) == "..")
                {
                    if (!String.IsNullOrEmpty(livepath))
                    {
                        livepath = livepath.Remove(livepath.LastIndexOf("/", StringComparison.Ordinal));
                        if (String.IsNullOrEmpty(livepath))
                        {
                            livepath = "/";
                        }
                    }

                    newPath = newPath.Remove(0, 2);
                    continue;
                }
            }

            if (newPath[0] == '/')
            {
                newPath = newPath.Remove(0, 1);
                if (newPath[0] == '.')
                {
                    continue;
                }
            }

            if (livepath.Last() != '/')
            {
                livepath += "/";
            }

            var nextPath = newPath.IndexOf("/", StringComparison.Ordinal);
            if (nextPath == -1)
            {
                livepath += newPath;
                newPath = "";
            }
            else
            {
                livepath += newPath.Substring(0, nextPath);
                newPath = newPath.Remove(0, nextPath);
            }
        }
    }

     static void Main(string[] args)
    {
        try
        {

            string actual = System.Configuration.ConfigurationManager.AppSettings["path"].ToString();
            string cdpath = System.Configuration.ConfigurationManager.AppSettings["changedir"].ToString();
            Checkpath cp = new Checkpath(actual);
            cp.changedir(cdpath);
            Console.WriteLine("Chaged path is "+cp.livepath);
            Console.ReadLine();
            Console.ReadKey();
        }
        catch(Exception e)
        {
            Console.WriteLine("Error occured" + e.Message + e.StackTrace);
        }
    }
}