﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadFile
{
    class Readdata
    {
        
        TextWriter tw;
        string each_line = string.Empty;

        public void  write()
        {
            string src_path = @"C:\Exam\info.txt";
            string destination = @"C:\Exam\error.txt";
           if (!(File.Exists(destination)))
            {
                try
                {
                    tw = new StreamWriter(destination, true);
                }
            
                catch(Exception e)
                 {
                    Console.Write("Exception occured "+e.Message);
                 }
            }
            else
            {
                tw = new StreamWriter(destination, true);
            }
          
                using (StreamReader sr = new StreamReader(src_path))
                {

                  while ((each_line = sr.ReadLine()) != null)
                    {
                        each_line = each_line.ToLower();
                        if (each_line.Contains("error") || each_line.Contains("warning"))
                        {
                            tw.WriteLine(each_line);
                        }
                     }
                
                sr.Close();
                }
            tw.Close();
           }
    }
}




