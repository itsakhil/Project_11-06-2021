﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace ReadFile
{
    class Program
    {
        static void Main(string[] args)
        {
             Readdata rd = new Readdata();
             rd.write();

        }
    }
}
