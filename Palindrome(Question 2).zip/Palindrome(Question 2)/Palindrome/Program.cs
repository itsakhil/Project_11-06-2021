﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Word will be picked from Appconfig file");
          
            Checkpalindrome cp = new Checkpalindrome();
            cp.check();
        }
    }
}
